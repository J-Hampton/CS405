// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception>

bool do_even_more_custom_application_logic()
{
    // Throw logic error with message
    throw std::logic_error(std::string("Error: Method do_even_more_custom_application_logic"));

    std::cout << "Running Even More Custom Application Logic." << std::endl;

    return true;
}
void do_custom_application_logic()
{
    // Try catch block to handle exepction thrown in do_even_more_custom_application_logic method
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if(do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::logic_error& exception) {
        std::cerr << "exception caught: " << exception.what() << '\n';
    }
    // custom string exception throw
    std::string except = "This is a custom exception";
    throw except;

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // Check den for 0 then throw divide by zero runtime error if den is equal to 0 
    if (den == 0) {
        throw std::runtime_error(std::string("Error: Divide by 0 error"));
    }
    return (num / den);
}

void do_division() noexcept
{
    // try block for divide method call
    try {
        float numerator = 10.0f;
        float denominator = 0;

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    // catch block to catch runtime errors from try block
    catch (std::runtime_error& exception) {
        std::cerr << "exception caught: " << exception.what() << '\n';
    }
}

int main()
{
    //Try catch block to catch string custom exception, then all std::exceptions, then any uncaught exceptions
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        do_division();
        do_custom_application_logic();
    }

    catch (std::string& exception) {
        std::cerr << "exception caught: " << exception << '\n';
    }
    catch (std::exception& exception) {
        std::cerr << "std::exception caught:" << exception.what() << '\n';
    }
    catch (...) {
        std::cerr << "Unhandled Exception caught:" << '\n';
    }

}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu